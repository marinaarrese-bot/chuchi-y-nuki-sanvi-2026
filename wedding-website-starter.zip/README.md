# Wedding Website Starter (GitHub Pages)

A simple, aesthetic, mobile-friendly one-page wedding website you can deploy free on **GitHub Pages**.

## Quick Start

1. **Edit content** in `index.html` (names, date, city, schedule, hotels, menu).
2. Replace images in `assets/img/` (optional). Suggested files:
   - `hero-placeholder.jpg` (large, ~2000px wide)
   - `favicon.png` (32×32 or 64×64)
3. (Optional) Tweak colors in `assets/css/styles.css` under `:root` variables.
4. Create a repo on GitHub and upload these files.
5. In **Settings → Pages**, set Source to your default branch. Wait for deploy.
6. Share the public URL 🎉

## Custom Domain

- Buy a domain from a registrar (e.g., namecheap, Google Domains legacy, porkbun).
- In repo: add a file named `CNAME` with your domain (e.g., `samandleah.com`).
- Update DNS at your registrar: create `A` records pointing to GitHub Pages IPs and a `CNAME` for subdomains. See GitHub Pages docs for current values.
- GitHub will issue HTTPS after DNS propagates.

## Replacing RSVP

- Create a Google Form (or Typeform) with fields you need.
- Replace the RSVP link in the `#rsvp` section.
- You can also **embed** the form using an `<iframe>` Google gives you.

## Accessibility & Performance Notes

- Text has sufficient contrast; headings use a readable serif.
- Images should include `alt` text where used.
- Keep image sizes optimized for faster loads (try 1600–2000px for hero, 1200px for others).

## Where to edit content

Look for comments and the following landmarks in `index.html`:
- **Wedding Details** (`#details`)
- **Program** (`#schedule`)
- **Venue & Hotels** (`#venue`)
- **Menu** (`#menu`)
- **RSVP** (`#rsvp`)
- **FAQ** (`#faq`)

## License

MIT — enjoy and customize.
